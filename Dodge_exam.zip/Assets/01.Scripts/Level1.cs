using UnityEngine;

public class Level1 : MonoBehaviour
{

    void Start()
    {

    }

    void Update()
    {

    }
}
