using UnityEngine;

public class Level2 : MonoBehaviour
{


    void Start()
    {

    }

    void Update()
    {

    }
}
